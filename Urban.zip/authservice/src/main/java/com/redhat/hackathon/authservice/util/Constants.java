package com.redhat.hackathon.authservice.util;

public class Constants {

	public static final String USER_DOES_NOT_EXISTS="User Does Not Exists";
	
	public static final String LOGIN_SUCCESSFUL="Login Successful";
	
	public static final String INCORRECT_PASSWORD="Please enter correct UserId and Password";
	
	public static final String PASSIVE="Passive";
	
	
}
