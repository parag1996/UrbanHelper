INSERT INTO UserDetails (USERID, PASSWORD, FIRSTNAME,LASTNAME,MOBILENUMBER,EMAILID,ADDRESSLINE1,ADDRESSLINE2,ADDRESSLINE3,CITY,STATE,COUNTRY,ZIP,ZIP4,AADHARNUMBER,STATUS) VALUES
  ('5000','Tejas123','Tejas','Mawande', 9997000,'tejas@gmail.com','Lane20','Dahanukar','Kothrud','Pune','Maharashtra','India',444,011,0111,'Active'),
    ('5001','Parag123','Parag','Patil', 9997000,'parag@gmail.com','Lane20','Dahanukar','Kothrud','Pune','Maharashtra','India',441,011,0112,'Passive')
 ;