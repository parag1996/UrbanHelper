package com.redhat.hackathon.registration.validator;

public class RegistrationValidator {

}
