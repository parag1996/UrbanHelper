package com.redhat.hackathon.registration.util;

public class Constants {
public static final String USER_REGISTERED_SUCCESSFULLY="User registered successfully";

public static final String SUCCESS="SUCCESS";

public static final String DELETED_SUCCESSFULLY="User deleted successfully";

public static final String USER_ALREDADY_EXISTS="User Already Exists";
public static final String USER="User";

public static final String PASSIVE="Passive";

public static final String PASSWORD_UPDATED_SUCCESSFULLY="Password updated successfully";

public static final String USER_DOES_NOT_EXISTS="User does not exists";

}
